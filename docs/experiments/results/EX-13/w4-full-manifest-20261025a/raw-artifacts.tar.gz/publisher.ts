import { readFile, writeFile } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { Type } from 'typebox';
import { Check } from 'typebox/value';
import { bindingFor, describeArtifact, publishRun, sha256 } from '/contracts-local/experiments/contracts/records.ts';
import { parseObservations, parseRun } from '/contracts-local/experiments/contracts/schema.ts';
import type { Run } from '/contracts-local/experiments/contracts/schema.ts';

const repository = '/app';
const evidenceRoot = '/qualification/artifacts/hospital-full-manifest-20261025a';
const sourceCommit = 'c83375e44c92ebd206dff4da002b334b54e2da62';
const contractCommit = 'a98b6cd49c637f40dd7431196bd98349bcc4a466';
const rawObservations: unknown = JSON.parse(await readFile(`${evidenceRoot}/observations.json`, 'utf8'));
const observations = parseObservations(rawObservations);
const registry: unknown = JSON.parse(await readFile(`${repository}/docs/experiments/registry.json`, 'utf8'));
const registrySchema = Type.Object({ experiments: Type.Array(Type.Object({ id: Type.String(), assertions: Type.Array(Type.String()) })) });
if (!Check(registrySchema, registry)) throw new Error('Invalid pinned experiment registry.');
const definition = registry.experiments.find(item => item.id === 'EX-13');
if (!definition || definition.assertions.length !== 5) throw new Error('Unexpected bound EX-13 definition.');
const design = await bindingFor(repository, 'docs/design/versioned-model-candidate.md');
const definitionBinding = await bindingFor(repository, 'docs/experiments/registry.json');
if (design.commit !== sourceCommit || definitionBinding.commit !== sourceCommit) throw new Error('Wrong generation source binding.');
const contractBindings = [];
for (const path of ['experiments/contracts/schema.ts', 'experiments/contracts/records.ts', 'experiments/contracts/cli.ts']) {
  const binding = await bindingFor('/contracts-local', path);
  if (binding.commit !== contractCommit) throw new Error('Unexpected metadata writer source.');
  contractBindings.push(binding);
}
await writeFile(`${evidenceRoot}/contract-bindings.json`, `${JSON.stringify(contractBindings, null, 2)}\n`, { flag: 'wx' });
const rawPaths = [
  'manifest.json', 'manifest.sha256', 'time-v.txt', 'started-at.txt', 'generation-started-at.txt',
  'finished-at.txt', 'exit-code.txt', 'stderr.log', 'image.json', 'container.json', 'command.txt',
  'requested-source-commit.txt', 'source-commit.txt', 'source-status.txt', 'source-sha256.txt',
  'source-checkout.log', 'shared-budget.ndjson', 'node-version.txt', 'time-version.txt',
  'time-executable.sha256', 'runner.sh', 'runner.sha256', 'observations.json', 'coordinator-handoff.json',
  'prior-failures.md', 'publisher.ts', 'contract-bindings.json',
  'contract-snapshot/schema.ts', 'contract-snapshot/records.ts', 'contract-snapshot/cli.ts',
];
execFileSync('tar', ['-czf', `${evidenceRoot}/raw-artifacts.tar.gz`, '-C', evidenceRoot, ...rawPaths]);
const evidence: Run['evidence'] = [];
for (const path of [...rawPaths, 'raw-artifacts.tar.gz']) {
  const mediaType = path.endsWith('.json') ? 'application/json' : path.endsWith('.gz') ? 'application/gzip' : 'text/plain';
  evidence.push(await describeArtifact(evidenceRoot, path, mediaType));
}
const manifestSha256 = sha256(await readFile(`${evidenceRoot}/manifest.json`));
if (manifestSha256 !== 'efd1ef057d1f4513b0b89cf380c1fcd6cf0bdc31bd468ce466d3302734484737') throw new Error('Full manifest changed.');
const ids = [
  ['w4-full-generated-counts', 'w4-full-degree-reconciliation'], ['w4-full-generated-counts'], [],
  ['w4-full-generator-resource-envelope'], ['w4-synthetic-claim-boundary'],
];
const coverage = definition.assertions.map((assertion, index) => ({
  assertion, caseIds: ids[index] ?? [], coverage: index === 4 ? 'covered' : index === 2 ? 'not-covered' : 'partial',
}));
const run = parseRun({
  schemaVersion: 1, recordKind: 'run', experimentId: 'EX-13', runId: 'w4-full-manifest-20261025a',
  executionStatus: 'completed', conclusion: 'inconclusive',
  startedAt: (await readFile(`${evidenceRoot}/started-at.txt`, 'utf8')).trim(),
  finishedAt: (await readFile(`${evidenceRoot}/finished-at.txt`, 'utf8')).trim(),
  hypothesis: 'The full seeded hospital generator can produce the declared inventory, exact logical property cohorts, typed graph counts and query oracles with bounded memory. This generator-only run cannot establish all EX-13 database assertions.',
  variant: 'VM-C1 synthetic initial revision, full hospital profile, standalone manifest production without SQL backend execution.',
  design: { candidateId: 'VM-C1', ...design }, definition: definitionBinding,
  implementation: { sourceCommit, runnerCommit: sourceCommit, validators: [
    'Pinned generator manifest checks reconcile per-kind incoming/outgoing degree sums with streamed edge counts.',
    'Earlier isolated correction-source validation: npm run validate, scoped tsc, seven generator tests. These checks were not rerun during full generation.',
    'Metadata publication uses W0 writer a98b6cd with exact observation artifact, Git bindings and evidence hashes.',
  ] },
  dataset: { name: 'hospital-200k-v1/full', seed: 'bim-forge-hospital-200k-v1', manifestSha256 },
  environment: {
    host: 'fun-server', software: {
      node: (await readFile(`${evidenceRoot}/node-version.txt`, 'utf8')).trim(),
      typebox: '1.4.3, pinned by source package manifest',
      generator: sourceCommit, metadataWriter: contractCommit,
      time: 'GNU Time version string UNKNOWN; exact executable hash and version output are retained.',
      observations: 'Generator-only observations derived after execution from retained manifest, exit status and GNU time output.',
    },
    imageDigests: ['sha256:4b96c3cba2f461d2bb9b6a285e5514fcf58968c9614eddd3441bcdb2def38dff'],
    cpuLimit: 1, memoryLimitBytes: 1073741824, diskBudgetBytes: 214748364800,
    storage: `Private durable evidence root ${evidenceRoot} on /ssd1. The 200 GiB cap covered the shared qualification root; watchdog also required 100 GiB data and 4 GiB host-root reserves. Evidence paths are relative to this root; raw-artifacts.tar.gz preserves the listed raw files for review.`,
    cacheProcedure: 'No cache flush or cold-cache claim. Pure generation overlapped other qualification clients; no database writes or comparative workload ran in this container.',
    measurementSlot: 'Coordinator-authorized full manifest admission job only, 2026-10-25T12:08:14Z to 12:17:01Z; one CPU, one GiB, networking disabled, two-hour timeout.',
  },
  commands: [
    'bash /qualification/sources/w4-debug/full-manifest-run.sh (retained launcher, Docker image/mounts and hashes are evidence)',
    'cp -R /source/. /app/; git -c safe.directory=/app checkout --detach c83375e44c92ebd206dff4da002b334b54e2da62',
    'timeout --signal=TERM --kill-after=10s <remaining-of-7200-seconds>s /usr/bin/time -v -o time-v.txt node benchmarks/hospital/generator/cli.ts --scale full --table manifest',
  ],
  observations, observationsArtifact: 'observations.json', coverage, evidence, errors: [],
  limitations: [
    'This is an inconclusive EX-13 generator contribution. Database admission, full SQL integrity, history, query/delta execution, traffic, durability, recovery and approval evidence remain separate coordinator/W5 work.',
    'Independent endpoint, duplicate and COPY round-trip checks ran at smoke scale earlier. Full generation checked aggregate degrees and hashed all emitted rows without loading them into a second system.',
    'Synthetic bounds, inventory, source references and external URIs do not qualify real hospital inventory, rendering, clashes, IFC fidelity or geometry regeneration.',
    'Only initial revision 1 is materialized; external artifact bytes are zero. Payload compression/deduplication uses bounded samples.',
    'GNU time reports 8:41.13 and 181612 KiB maximum process RSS. These are generation admission metadata under overlapping activity, not isolated comparative performance or whole-service peak memory.',
    'Earlier rounding and boundary-test failures remain documented in prior-failures.md. Their complete raw console output is in the task transcript, not a retained standalone log; no failed-run timestamps or terminal record were invented.',
    'The archive in this result directory retains the raw evidence. Extract it into an evidence root, retain the archive itself there too, and verify with W0 a98b6cd. No human acceptance, registry update or merge approval is recorded here.',
  ],
  decisionImplications: [
    'The actual full input has 6777445 entities, 18742644 relationships, 1500000 parameters and 145118512 logical property values; generation hashes are available for independent loader comparison.',
    'Keep the EX-13 qualification conclusion inconclusive until missing database assertions have their own reviewed evidence. Do not infer production schema adoption from this producer run.',
    'Preserve existing smoke/reduced failures and retries; this unique run supplements them and replaces none of their files.',
  ],
});
const path = await publishRun(run, { repository, evidence: evidenceRoot, results: '/qualification/published' });
process.stdout.write(`${path}\n`);
