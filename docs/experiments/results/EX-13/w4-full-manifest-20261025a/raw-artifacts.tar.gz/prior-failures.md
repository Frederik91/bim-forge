# Preserved W4 failure history

This is a historical evidence note, not a newly executed test or a complete raw console log.

- Initial source e2282848d200b47cff42758394dfc1c941c066ec failed the full-admission assertion. Expected 145118512; actual floating-point cohort arithmetic returned 145118992. Five other generator tests passed in the coordinator's first attempt.
- The leased W4 debug container reproduced the same assertion before a fix. A minimized boundary regression then failed for the last small-cohort stud: actual 48 logical values, expected 16.
- Probe output showed stud 1400000 * 0.7 = 979999.9999999999, and electricalOutlet / ductSegment 180000 * 0.7 = 125999.99999999999. Flooring moved each cohort boundary one entity downward and increased logical values by 160 per kind, totaling 480.
- Exact integer ratios independently retain 145118512. Source c83375e44c92ebd206dff4da002b334b54e2da62 precomputes exact decimal boundaries; all seven generator tests then passed. The new full manifest generated 145118512 actual logical property values.
- Debug setup also encountered a CR in an SSH-fed shell path, missing TypeBox resolution until the image's /app/node_modules was linked at /node_modules, and a temporary Git safe-directory issue. None was represented as a dataset experiment result.
- Combined W4/W5 root validation initially lacked pg dependencies in the unmodified tools image. W4-only root validation and scoped integration TypeScript passed; the coordinator subsequently reported combined validation and 23 tests passing.

Complete original failure/stdout excerpts are retained in the task conversation. No missing timestamps, raw-log files or failed terminal run were fabricated. Existing coordinator smoke/reduced records and artifacts remain untouched.
