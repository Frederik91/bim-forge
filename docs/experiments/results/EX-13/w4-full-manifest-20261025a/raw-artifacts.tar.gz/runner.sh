#!/bin/bash
set -euo pipefail
R=/qualification
E=$R/artifacts/hospital-full-manifest-20261025a
SOURCE=c83375e44c92ebd206dff4da002b334b54e2da62
started_epoch=$(date +%s)
job_pid=
finish() {
  rc=$?
  trap - EXIT
  if [ -n "$job_pid" ] && kill -0 "$job_pid" 2>/dev/null; then
    kill -TERM -- "-$job_pid" 2>/dev/null || true
  fi
  date -u +%FT%TZ > "$E/finished-at.txt"
  printf '%s\n' "$rc" > "$E/exit-code.txt"
  if [ "$rc" -eq 0 ]; then sha256sum "$E/manifest.json" > "$E/manifest.sha256"; fi
  exit "$rc"
}
trap finish EXIT
date -u +%FT%TZ > "$E/started-at.txt"
printf '%s\n' "$SOURCE" > "$E/requested-source-commit.txt"
budget_check() {
  used=$(du -sb "$R" | cut -f1)
  root=$(df -B1 --output=avail /host-root | tail -1 | tr -d ' ')
  data=$(df -B1 --output=avail "$R" | tail -1 | tr -d ' ')
  printf '{"timestamp":"%s","usedBytes":%s,"rootAvailableBytes":%s,"dataAvailableBytes":%s}\n' "$(date -u +%FT%TZ)" "$used" "$root" "$data" >> "$E/shared-budget.ndjson"
  if [ -e "$R/BUDGET-STOP" ] || [ -e "$R/artifacts/hospital-20261025a/BUDGET-STOP" ] || [ -e "$E/BUDGET-STOP" ]; then
    echo 'Existing BUDGET-STOP detected' > "$E/stop-reason.txt"
    return 1
  fi
  if [ "$used" -gt 214748364800 ] || [ "$root" -lt 4294967296 ] || [ "$data" -lt 107374182400 ]; then
    echo 'Shared 200 GiB budget or 100 GiB data / 4 GiB root reserve breached' > "$E/BUDGET-STOP"
    cp "$E/BUDGET-STOP" "$E/stop-reason.txt"
    return 1
  fi
}
budget_check || exit 125
cp -R /source/. /app/
cd /app
git -c safe.directory=/app checkout --detach "$SOURCE" > "$E/source-checkout.log" 2>&1
actual=$(git -c safe.directory=/app rev-parse HEAD)
printf '%s\n' "$actual" > "$E/source-commit.txt"
test "$actual" = "$SOURCE"
git -c safe.directory=/app status --porcelain -- benchmarks/hospital/generator benchmarks/hospital/profile.json > "$E/source-status.txt"
test ! -s "$E/source-status.txt"
sha256sum benchmarks/hospital/profile.json benchmarks/hospital/generator/*.ts > "$E/source-sha256.txt"
/usr/bin/time --version > "$E/time-version.txt" 2>&1
sha256sum /usr/bin/time > "$E/time-executable.sha256"
node --version > "$E/node-version.txt"
printf '%s\n' 'node benchmarks/hospital/generator/cli.ts --scale full --table manifest' > "$E/command.txt"
remaining=$((7200 - $(date +%s) + started_epoch))
test "$remaining" -gt 0
budget_check || exit 125
date -u +%FT%TZ > "$E/generation-started-at.txt"
timeout --signal=TERM --kill-after=10s "${remaining}s" /usr/bin/time -v -o "$E/time-v.txt" node benchmarks/hospital/generator/cli.ts --scale full --table manifest > "$E/manifest.json" 2> "$E/stderr.log" &
job_pid=$!
while kill -0 "$job_pid" 2>/dev/null; do
  if ! budget_check; then
    kill -TERM -- "-$job_pid" 2>/dev/null || true
    sleep 5
    kill -KILL -- "-$job_pid" 2>/dev/null || true
    wait "$job_pid" 2>/dev/null || true
    job_pid=
    exit 125
  fi
  sleep 20
done
if wait "$job_pid"; then rc=0; else rc=$?; fi
job_pid=
exit "$rc"
